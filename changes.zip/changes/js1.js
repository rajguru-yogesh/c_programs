function myFunction() {
	$("#modalLoginAvatarDemo1").modal();
}
function myFunction2() {
  $("#modalLoginAvatarDemo2").modal();
}
function myFunction3() {
$("#modalLoginAvatarDemo3").modal();
}
function myFunction4() {
$("#modalLoginAvatarDemo4").modal();
}
